use sakila;
select distinct amount from payment order by amount desc limit 1,1;

