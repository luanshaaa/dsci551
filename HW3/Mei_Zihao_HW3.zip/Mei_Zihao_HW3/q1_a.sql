use sakila;
select * from actor where first_name like "%er%";

